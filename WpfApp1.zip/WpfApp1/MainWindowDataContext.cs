﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public class MainWindowDataContext
    {
        public string? UserName { get; set; }
        public MainWindowDataContext() { }
    }
}
