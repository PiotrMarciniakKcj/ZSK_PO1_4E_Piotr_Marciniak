﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Calculator
{
    public static class NumbersService
    {
        public static double[] GetNumbers(string path)
        {
            int length = File.ReadAllLines(path).Length;
            List<String> contents = File.ReadAllLines(path).ToList();
            double[] numbersList = new double[length*2];
            int j = 0;
            foreach (string line in contents)
            {
                string[] huj = line.Split(";");
                numbersList[j] = (double)double.Parse(huj[0]);
                numbersList[j+1] = (double)double.Parse(huj[1]);

                j += 2;
            }


            return numbersList;
        }
        

        
    }
}
